// Código da página cursos.html
chrome('cursos');$('#grid').innerHTML=DB.cursos.map(card).join('');$('#fb').innerHTML=feedbacks();
