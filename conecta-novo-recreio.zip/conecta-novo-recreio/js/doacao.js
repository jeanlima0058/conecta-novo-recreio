// Código da página doacao.html
chrome('doacao');
$('#copy').onclick=async()=>{try{await navigator.clipboard.writeText($('#pix').value);$('#copy').textContent='Copiado!'}catch(_){$('#pix').select()}setTimeout(()=>$('#copy').textContent='Copiar',2000)};
