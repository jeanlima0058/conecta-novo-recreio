// Dados, sessão e utilidades compartilhadas. Demonstração: tudo fica no navegador (localStorage).
const S=(()=>{try{localStorage.setItem('_t','1');return localStorage}catch(e){const m=parent.__mem=parent.__mem||{};return{getItem:k=>m[k]??null,setItem:(k,v)=>{m[k]=String(v)},removeItem:k=>{delete m[k]}}}})();
const $=(s,r=document)=>r.querySelector(s),$$=(s,r=document)=>[...r.querySelectorAll(s)];
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const fd=d=>d.split('-').reverse().join('/');
const today=()=>new Date().toISOString().slice(0,10);
const go=u=>parent!==window&&parent.__nav?parent.__nav(u):(location.href=u);
const ADMIN={u:'admin@conecta.org',s:'Recreio@2026'}; // login único do administrador
const seed=()=>({
 cursos:[
  {id:1,e:'💻',nome:'Informática básica',carga:'40 horas',desc:'Windows, internet e pacote de escritório.',det:'Do primeiro clique ao currículo digital: os alunos aprendem a usar o computador, navegar com segurança, escrever textos e montar planilhas simples. Cada aluno tem seu próprio equipamento durante as aulas.',pub:'10 a 17 anos',hor:'Seg e qua, 14h às 16h',prof:'Carlos Lima',vagas:20},
  {id:2,e:'🎨',nome:'Artes e desenho',carga:'30 horas',desc:'Desenho, pintura e criatividade.',det:'Oficinas de desenho de observação, aquarela e colagem. O material é fornecido pela instituição e os trabalhos entram na exposição de fim de ano.',pub:'6 a 14 anos',hor:'Ter e qui, 14h às 15h30',prof:'Helena Prado',vagas:18},
  {id:3,e:'🎵',nome:'Música',carga:'36 horas',desc:'Violão, canto e ritmo em grupo.',det:'Aulas coletivas de violão, canto coral e percussão. Os instrumentos são emprestados durante o curso e a turma se apresenta na feira de talentos.',pub:'8 a 17 anos',hor:'Sex, 14h às 17h',prof:'Rafael Mota',vagas:16},
  {id:4,e:'📚',nome:'Reforço escolar',carga:'60 horas',desc:'Português e matemática com apoio individual.',det:'Acompanhamento em português e matemática com turmas pequenas, tarefas orientadas e lanche. Os professores conversam com as famílias a cada bimestre.',pub:'7 a 15 anos',hor:'Seg a qui, 9h às 11h',prof:'Marta Souza',vagas:25},
  {id:5,e:'⚽',nome:'Esportes',carga:'24 horas',desc:'Futsal, vôlei e atividades em equipe.',det:'Treinos de futsal e vôlei com foco em cooperação e saúde. Uniformes e bolas são fornecidos; é necessário atestado médico simples.',pub:'8 a 17 anos',hor:'Sáb, 9h às 11h',prof:'Diego Alves',vagas:30},
  {id:6,e:'🌱',nome:'Horta e meio ambiente',carga:'20 horas',desc:'Plantio, compostagem e cuidado com a natureza.',det:'As crianças plantam, regam e colhem na horta comunitária do bairro, aprendem a compostar e levam mudas para casa.',pub:'6 a 12 anos',hor:'Qua, 9h às 11h',prof:'Dona Lúcia',vagas:15}],
 turmas:[{id:1,nome:'Informática – Turma A',curso:1,hor:'Seg e qua · 14h',prof:'Carlos Lima'},{id:2,nome:'Música – Turma B',curso:3,hor:'Sex · 14h',prof:'Rafael Mota'},{id:3,nome:'Reforço – Turma C',curso:4,hor:'Seg a qui · 9h',prof:'Marta Souza'}],
 alunos:[
  {id:1,nome:'Ana Souza',mat:'2026001',senha:'ana123',turma:1,prog:65,faltas:[{d:'2026-09-12',m:'Consulta médica'},{d:'2026-10-03',m:'Sem justificativa'}],notas:[{a:'Prova 1',n:8.5},{a:'Trabalho em grupo',n:9},{a:'Prova 2',n:7.5}]},
  {id:2,nome:'Bruno Lima',mat:'2026002',senha:'bruno123',turma:2,prog:40,faltas:[],notas:[{a:'Apresentação',n:8}]},
  {id:3,nome:'Clara Mendes',mat:'2026003',senha:'clara123',turma:1,prog:80,faltas:[{d:'2026-08-20',m:'Doença'}],notas:[{a:'Prova 1',n:9.5},{a:'Prova 2',n:9}]}],
 avisos:[{id:1,t:'Feira de talentos',x:'Venha apresentar o que aprendeu. As famílias estão convidadas!',d:'2026-10-20',turma:0},{id:2,t:'Recesso de feriado',x:'Não haverá aulas na sexta, 13 de novembro.',d:'2026-10-22',turma:0},{id:3,t:'Traga um pen drive',x:'Na próxima aula vamos salvar os trabalhos de planilha.',d:'2026-10-23',turma:1}],
 eventos:[{id:1,d:'2026-11-05',t:'Prova 3',turma:1},{id:2,d:'2026-11-14',t:'Feira de talentos',turma:0},{id:3,d:'2026-11-20',t:'Entrega dos trabalhos finais',turma:1},{id:4,d:'2026-12-10',t:'Formatura das turmas',turma:0}],
 inscr:[]});
let DB;try{DB=JSON.parse(S.getItem('cnr_db'))}catch(e){}
DB=DB||seed();
const save=()=>S.setItem('cnr_db',JSON.stringify(DB));
const nid=a=>Math.max(0,...a.map(x=>x.id))+1;
const ses=()=>{try{return JSON.parse(S.getItem('cnr_ses'))}catch(e){return null}};
const login=(u,s)=>{u=u.trim();let r=null;
 if(u.toLowerCase()===ADMIN.u&&s===ADMIN.s)r={role:'admin'};
 else{const a=DB.alunos.find(x=>(x.mat===u||(x.email||'').toLowerCase()===u.toLowerCase())&&x.senha===s);if(a)r={role:'aluno',id:a.id}}
 if(r)S.setItem('cnr_ses',JSON.stringify(r));return r};
const logout=()=>{S.removeItem('cnr_ses');go('index.html')};
const guard=role=>{const s=ses();if(!s||s.role!==role){go('login.html');return null}return s};
function modal(html){const m=document.createElement('div');m.className='mdl';m.innerHTML=`<div class="mbox" role="dialog" aria-modal="true">${html}</div>`;
 const x=()=>{m.remove();removeEventListener('keydown',k)},k=e=>e.key==='Escape'&&x();addEventListener('keydown',k);
 m.onclick=e=>{if(e.target===m||e.target.closest('[data-x]'))x()};document.body.appendChild(m);($('input,select,button',m)||m).focus();return{el:m,close:x}}
const ask=(msg,ok)=>{const m=modal(`<div class="p-6"><p class="font-bold mb-5">${msg}</p><div class="flex gap-3 justify-end"><button class="btn btn-alt" data-x>Cancelar</button><button class="btn" id="yes" style="background:var(--bad);color:#fff">Excluir</button></div></div>`);$('#yes',m.el).onclick=()=>{m.close();ok()}};
const toast=m=>{const t=document.createElement('div');t.setAttribute('role','status');t.textContent=m;t.style.cssText='position:fixed;left:50%;bottom:1.5rem;transform:translateX(-50%);background:var(--ink);color:var(--bg);padding:.7rem 1.2rem;border-radius:999px;font-weight:700;z-index:60;max-width:90vw';document.body.appendChild(t);setTimeout(()=>t.remove(),3200)};
const art=(c,cls='')=>c.img?`<img src="${c.img}" alt="${esc(c.nome)}" class="${cls} object-cover w-full">`:`<div class="ph ${cls}" role="img" aria-label="${esc(c.nome)}">${c.e||'🎓'}</div>`;
