# Conecta Novo Recreio (Semente do Amanhã)

Site da ONG em HTML, CSS e JavaScript, agora dividido em páginas.

| Arquivo | Função |
|---|---|
| `index.html` | Home: carrossel em tela cheia, título e botões de login/cadastro |
| `cursos.html` | Catálogo de cursos (cards, “Saiba Mais”, “Inscreva-se”) e depoimentos |
| `sobre.html` | História, fundadores e objetivo |
| `doacao.html` | PIX e uso das doações |
| `login.html` | Página de login de reserva (o login normal abre em modal) |
| `painel-admin.html` + `js/admin.js` | Dashboard do administrador |
| `painel-aluno.html` + `js/aluno.js` | Painel do aluno |
| `js/home.js`, `cursos.js`, `sobre.js`, `doacao.js`, `login.js` | Código de cada página (HTML sem JavaScript embutido) |
| `js/data.js` | Dados, sessão, login e utilidades |
| `js/site.js` | Cabeçalho, rodapé, cards de curso e modais |
| `css/style.css` | Estilos compartilhados |

## Logins de demonstração
- Admin: `admin@conecta.org` / `Recreio@2026` (definido em `ADMIN`, em `js/data.js`)
- Alunos: matrícula `2026001` / `ana123`, `2026002` / `bruno123`, `2026003` / `clara123`

## Importante
Os dados ficam no `localStorage` do navegador e o login é validado no front-end. Serve para demonstração. Para uso real, troque `js/data.js` por chamadas a um back-end com autenticação.
