// Painel do administrador
const me=guard('admin');let cur='resumo',flt=0,pend=null;const V={},F={},A={};
const T=t=>`<h1 class="text-3xl font-bold mb-6">${t}</h1>`;
const tb=(h,r)=>`<div class="card overflow-x-auto"><table class="tbl"><thead><tr>${h.map(x=>`<th>${x}</th>`).join('')}</tr></thead><tbody>${r.length?r.join(''):`<tr><td colspan="${h.length}" class="mute">Nada cadastrado ainda.</td></tr>`}</tbody></table></div>`;
const del=(a,id,l)=>`<button class="btn btn-alt btn-sm" style="color:var(--bad)" data-a="${a}:${id}" aria-label="Excluir ${esc(l)}">Excluir</button>`;
const fld=(n,l,x='')=>`<div><label for="${n}">${l}</label><input id="${n}" name="${n}" class="inp" ${x}></div>`;
const sel=(arr,v)=>arr.map(x=>`<option value="${x.id}"${x.id==v?' selected':''}>${esc(x.nome)}</option>`).join('');
const turmaN=id=>(DB.turmas.find(t=>t.id==id)||{nome:'Sem turma'}).nome;
const cursoN=id=>(DB.cursos.find(c=>c.id==id)||{nome:'—'}).nome;
const alvo=id=>id?turmaN(id):'Toda a instituição';
const img=f=>new Promise(r=>{const fr=new FileReader;fr.onload=()=>{const i=new Image;i.onload=()=>{const k=Math.min(1,800/i.width),c=document.createElement('canvas');c.width=i.width*k;c.height=i.height*k;c.getContext('2d').drawImage(i,0,0,c.width,c.height);r(c.toDataURL('image/jpeg',.8))};i.src=fr.result};fr.readAsDataURL(f)});
const cred=a=>modal(`<div class="p-6 text-center"><div class="text-4xl mb-2">🔑</div><h2 class="text-xl font-bold mb-2">Login de ${esc(a.nome)}</h2><p class="mute mb-3">Entregue estas credenciais ao aluno:</p><p>Matrícula: <b>${a.mat}</b></p><p class="mb-5">Senha: <b>${esc(a.senha)}</b></p><button class="btn" data-x>Fechar</button></div>`);
const novoAluno=(nome,turma)=>{const id=nid(DB.alunos),a={id,nome,mat:'2026'+String(id).padStart(3,'0'),senha:Math.random().toString(36).slice(2,8),turma,prog:0,faltas:[],notas:[]};DB.alunos.push(a);return a};

const st=(k,a)=>`<td><span class="tag" style="${a.ativo===false?'':'background:var(--leaf);color:#fff;border-color:var(--leaf)'}">${a.ativo===false?'Desativado':'Ativo'}</span> <button class="btn btn-alt btn-sm" data-a="${k}:${a.id}">${a.ativo===false?'Ativar':'Desativar'}</button></td>`;
V.resumo=()=>T('Visão geral')+`<div class="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">${[['Alunos',DB.alunos.length,'🧒'],['Turmas',DB.turmas.length,'🏫'],['Cursos',DB.cursos.length,'📚'],['Inscrições novas',DB.inscr.length,'📬']].map(([a,b,c])=>`<div class="card p-5"><div class="text-2xl" aria-hidden="true">${c}</div><div class="text-3xl font-bold" style="font-family:Fraunces,serif">${b}</div><div class="mute">${a}</div></div>`).join('')}</div><h2 class="text-xl font-bold mb-3">Turmas</h2>`+
 tb(['Turma','Curso','Alunos','Progresso médio'],DB.turmas.map(t=>{const al=DB.alunos.filter(a=>a.turma===t.id),m=al.length?Math.round(al.reduce((s,a)=>s+a.prog,0)/al.length):0;return `<tr><td><b>${esc(t.nome)}</b></td><td>${esc(cursoN(t.curso))}</td><td>${al.length}</td><td><div class="bar w-32"><i style="width:${m}%"></i></div><small>${m}%</small></td></tr>`}));

V.cursos=()=>T('Cursos')+`<form id="fC" class="grid md:grid-cols-2 gap-6 mb-8"><label for="foto" class="card p-6 grid place-items-center text-center cursor-pointer min-h-[260px] relative overflow-hidden" style="border:3px dashed var(--brand)"><img id="pv" alt="" class="absolute inset-0 w-full h-full object-cover hidden"><span id="upl"><span class="block text-4xl" aria-hidden="true">⬆</span>Enviar foto do curso<small class="block mute">Clique para escolher</small></span><input id="foto" type="file" accept="image/*" class="sr-only"></label>
 <div class="space-y-3">${fld('nome','Nome do curso','required')}<div class="grid grid-cols-2 gap-3">${fld('carga','Carga horária','placeholder="40 horas" required')}${fld('vagas','Vagas','type="number" min="1" value="20"')}</div>${fld('pub','Público','placeholder="10 a 17 anos"')}${fld('hor','Dias e horário','placeholder="Seg e qua, 14h"')}${fld('prof','Professor(a)')}<div><label for="desc">Descrição</label><textarea id="desc" name="desc" rows="3" class="inp" required></textarea></div><button class="btn w-full">Adicionar curso</button></div></form>`+
 tb(['Curso','Carga','Professor(a)',''],DB.cursos.map(c=>`<tr><td><b>${c.e||'🎓'} ${esc(c.nome)}</b></td><td>${esc(c.carga)}</td><td>${esc(c.prof)}</td><td class="text-right">${del('delC',c.id,c.nome)}</td></tr>`));
F.fC=f=>{const d=Object.fromEntries(new FormData(f));DB.cursos.push({id:nid(DB.cursos),e:'🎓',nome:d.nome,carga:d.carga,vagas:d.vagas,pub:d.pub||'Todas as idades',hor:d.hor||'A definir',prof:d.prof||'A definir',desc:d.desc,det:d.desc,img:pend});pend=null;save();toast('Curso adicionado. Ele já aparece na página inicial.');show('cursos')};
A.delC=id=>ask('Excluir este curso? Ele sai da página inicial.',()=>{DB.cursos=DB.cursos.filter(c=>c.id!==id);save();show('cursos')});

V.turmas=()=>T('Turmas')+`<form id="fT" class="card p-5 grid md:grid-cols-4 gap-3 items-end mb-8">${fld('nome','Nome da turma','required')}<div><label for="curso">Curso</label><select id="curso" name="curso" class="inp">${sel(DB.cursos)}</select></div>${fld('hor','Horário','placeholder="Seg e qua · 14h"')}${fld('prof','Professor(a)')}<button class="btn md:col-span-4">Criar turma</button></form>`+
 tb(['Turma','Curso','Horário','Professor(a)','Alunos',''],DB.turmas.map(t=>{const al=DB.alunos.filter(a=>a.turma===t.id);return `<tr><td><b>${esc(t.nome)}</b></td><td>${esc(cursoN(t.curso))}</td><td>${esc(t.hor)}</td><td>${esc(t.prof)}</td><td>${al.length?esc(al.map(a=>a.nome).join(', ')):'<span class="mute">—</span>'}</td><td class="text-right">${del('delT',t.id,t.nome)}</td></tr>`}));
F.fT=f=>{const d=Object.fromEntries(new FormData(f));DB.turmas.push({id:nid(DB.turmas),nome:d.nome,curso:+d.curso,hor:d.hor||'A definir',prof:d.prof||'A definir'});save();toast('Turma criada.');show('turmas')};
A.delT=id=>ask('Excluir esta turma? Os alunos ficam sem turma.',()=>{DB.turmas=DB.turmas.filter(t=>t.id!==id);DB.alunos.forEach(a=>{if(a.turma===id)a.turma=0});save();show('turmas')});

V.alunos=()=>T('Alunos')+`<form id="fA" class="card p-5 grid md:grid-cols-3 gap-3 items-end mb-6">${fld('nome','Nome do aluno','required')}<div><label for="turma">Turma</label><select id="turma" name="turma" class="inp">${sel(DB.turmas)}</select></div><button class="btn">Cadastrar e gerar login</button></form>
 <div class="mb-3 max-w-xs"><label for="flt">Filtrar por turma</label><select id="flt" class="inp"><option value="0">Todas</option>${sel(DB.turmas,flt)}</select></div>`+
 tb(['Aluno','Matrícula','Turma','Progresso','Faltas','',''],DB.alunos.filter(a=>!flt||a.turma===flt).map(a=>`<tr><td><b>${esc(a.nome)}</b></td><td>${a.mat}</td><td>${esc(turmaN(a.turma))}</td><td><div class="bar w-24"><i style="width:${a.prog}%"></i></div><small>${a.prog}%</small></td><td>${a.faltas.length}</td><td><button class="btn btn-sm" data-a="lanc:${a.id}">Lançar</button></td><td class="text-right">${del('delA',a.id,a.nome)}</td></tr>`));
F.fA=f=>{const d=Object.fromEntries(new FormData(f)),a=novoAluno(d.nome.trim(),+d.turma);save();show('alunos');cred(a)};
A.delA=id=>ask('Excluir este aluno e o login dele?',()=>{DB.alunos=DB.alunos.filter(a=>a.id!==id);save();show('alunos')});
A.lanc=id=>{const a=DB.alunos.find(x=>x.id===id);
 const m=modal(`<div class="p-6 space-y-5"><h2 class="text-xl font-bold">${esc(a.nome)}</h2>
 <form data-k="n" class="flex flex-wrap gap-2 items-end"><div class="flex-1 min-w-[8rem]"><label>Avaliação</label><input name="a" class="inp" required></div><div class="w-24"><label>Nota</label><input name="v" type="number" min="0" max="10" step="0.1" class="inp" required></div><button class="btn btn-sm">Lançar nota</button></form>
 <form data-k="f" class="flex flex-wrap gap-2 items-end"><div><label>Data</label><input name="d" type="date" value="${today()}" class="inp" required></div><div class="flex-1 min-w-[8rem]"><label>Motivo</label><input name="m" class="inp" placeholder="Opcional"></div><button class="btn btn-sm">Registrar falta</button></form>
 <form data-k="p" class="flex gap-2 items-end"><div class="w-28"><label>Progresso %</label><input name="v" type="number" min="0" max="100" value="${a.prog}" class="inp" required></div><button class="btn btn-sm">Atualizar</button></form>
 <button class="btn btn-alt w-full" data-x>Fechar</button></div>`);
 $$('form',m.el).forEach(f=>f.onsubmit=e=>{e.preventDefault();const d=new FormData(f),k=f.dataset.k;
  if(k==='n')a.notas.push({a:d.get('a'),n:+d.get('v')});if(k==='f')a.faltas.push({d:d.get('d'),m:d.get('m')||'Sem justificativa'});if(k==='p')a.prog=Math.min(100,Math.max(0,+d.get('v')));
  save();m.close();toast('Atualizado.');show('alunos')})};

V.inscricoes=()=>T('Inscrições recebidas')+`<p class="mute mb-4">Quem usa o botão “Cadastre-se” já cria a própria conta de aluno. Esta lista mostra quem se cadastrou.</p>`+
 tb(['Nome','Contato','Curso','Data','',''],DB.inscr.map(i=>`<tr><td><b>${esc(i.nome)}</b></td><td>${esc(i.email)}<br><small class="mute">${esc(i.tel)}</small></td><td>${esc(cursoN(i.curso))}</td><td>${fd(i.d)}</td><td>${i.aluno?'<span class="tag">Conta criada</span>':`<button class="btn btn-sm" data-a="mat:${i.id}">Matricular</button>`}</td><td class="text-right">${del('delI',i.id,i.nome)}</td></tr>`));
A.mat=id=>{const i=DB.inscr.find(x=>x.id===id),t=DB.turmas.find(x=>x.curso===i.curso),a=novoAluno(i.nome,t?t.id:0);DB.inscr=DB.inscr.filter(x=>x.id!==id);save();show('inscricoes');cred(a)};
A.delI=id=>ask('Excluir esta inscrição?',()=>{DB.inscr=DB.inscr.filter(x=>x.id!==id);save();show('inscricoes')});

V.avisos=()=>T('Avisos e datas')+`<p class="mute mb-4">Só avisos e datas <b>ativos</b> aparecem para os alunos. Use o botão para ativar ou desativar a qualquer momento.</p><form id="fV" class="card p-5 grid md:grid-cols-2 gap-3 mb-8"><div><label for="tipo">Tipo</label><select id="tipo" name="tipo" class="inp"><option value="aviso">Aviso no mural</option><option value="data">Data importante</option></select></div><div><label for="turma">Para</label><select id="turma" name="turma" class="inp"><option value="0">Toda a instituição</option>${sel(DB.turmas)}</select></div>${fld('titulo','Título','required')}${fld('data','Data (só para datas importantes)','type="date"')}<div class="md:col-span-2"><label for="texto">Texto do aviso</label><textarea id="texto" name="texto" rows="2" class="inp"></textarea></div><button class="btn md:col-span-2">Publicar</button></form>
 <h2 class="text-xl font-bold mb-3">Mural</h2>`+tb(['Aviso','Para','Data','Para os alunos',''],DB.avisos.map(a=>`<tr><td><b>${esc(a.t)}</b><br><small class="mute">${esc(a.x)}</small></td><td>${esc(alvo(a.turma))}</td><td>${fd(a.d)}</td>${st('togV',a)}<td class="text-right">${del('delV',a.id,a.t)}</td></tr>`))+
 `<h2 class="text-xl font-bold my-3">Cronograma</h2>`+tb(['Evento','Para','Data','Para os alunos',''],[...DB.eventos].sort((a,b)=>a.d<b.d?-1:1).map(a=>`<tr><td><b>${esc(a.t)}</b></td><td>${esc(alvo(a.turma))}</td><td>${fd(a.d)}</td>${st('togE',a)}<td class="text-right">${del('delE',a.id,a.t)}</td></tr>`));
F.fV=f=>{const d=Object.fromEntries(new FormData(f));
 if(d.tipo==='data'){if(!d.data){toast('Informe a data.');return}DB.eventos.push({id:nid(DB.eventos),d:d.data,t:d.titulo,turma:+d.turma})}
 else DB.avisos.push({id:nid(DB.avisos),t:d.titulo,x:d.texto,d:today(),turma:+d.turma});
 save();toast('Publicado.');show('avisos')};
A.togV=id=>{const a=DB.avisos.find(x=>x.id===id);a.ativo=a.ativo===false;save();toast(a.ativo?'Aviso ativado para os alunos.':'Aviso desativado.');show('avisos')};
A.togE=id=>{const a=DB.eventos.find(x=>x.id===id);a.ativo=a.ativo===false;save();toast(a.ativo?'Data ativada para os alunos.':'Data desativada.');show('avisos')};
A.delV=id=>ask('Excluir este aviso?',()=>{DB.avisos=DB.avisos.filter(a=>a.id!==id);save();show('avisos')});
A.delE=id=>ask('Excluir esta data?',()=>{DB.eventos=DB.eventos.filter(a=>a.id!==id);save();show('avisos')});

function show(v){cur=V[v]?v:'resumo';$('#view').innerHTML=V[cur]();$$('#side a[data-v]').forEach(a=>a.classList.toggle('on',a.dataset.v===cur));$('#side').classList.remove('open');scrollTo(0,0)}
if(me){
 $('#view').addEventListener('click',e=>{const b=e.target.closest('[data-a]');if(b){const[a,id]=b.dataset.a.split(':');A[a](+id)}});
 $('#view').addEventListener('submit',e=>{e.preventDefault();F[e.target.id]?.(e.target)});
 $('#view').addEventListener('change',async e=>{
  if(e.target.id==='foto'&&e.target.files[0]){pend=await img(e.target.files[0]);$('#pv').src=pend;$('#pv').classList.remove('hidden');$('#upl').classList.add('hidden')}
  if(e.target.id==='flt'){flt=+e.target.value;show('alunos')}});
 $('#burger').onclick=()=>$('#side').classList.toggle('open');$('#out').onclick=logout;
 $('#side').addEventListener('click',e=>{const l=e.target.closest('a[data-v]');if(l){e.preventDefault();show(l.dataset.v)}});show('resumo');
}
