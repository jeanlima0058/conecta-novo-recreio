# Conecta Novo Recreio — Semente do Amanhã

Projeto em HTML, CSS e JavaScript organizado por área. O conteúdo e as funções existentes foram preservados.

| Pasta/arquivo | Conteúdo |
|---|---|
| `index.html` | Página inicial |
| `login/` | Página de login e seu JavaScript |
| `admin/` | Painel administrativo e seu JavaScript |
| `aluno/` | Painel do aluno e seu JavaScript |
| `cursos/` | Catálogo e seu JavaScript |
| `sobre/` | Página institucional e seu JavaScript |
| `doacao/` | Página de doações e seu JavaScript |
| `assets/css/style.css` | Estilos compartilhados |
| `assets/js/shared/data.js` | Dados, sessão, autenticação e utilidades |
| `assets/js/shared/site.js` | Cabeçalho, rodapé e modais compartilhados |
| `assets/js/home.js` | Comportamento da página inicial |
| `docs/` | Instruções de abertura |
| `scripts/` | Gerador da versão de arquivo único |
| `extras/abrir-tudo.html` | Versão de arquivo único gerada dos fontes |

## Abrir e editar

Extraia tudo e abra `index.html`. Para desenvolvimento, execute `python -m http.server 8000` na raiz e acesse `http://localhost:8000`. Tailwind e fontes dependem de internet.

Cada área tem seu `index.html` e o JavaScript correspondente. As páginas internas usam `<base href="../">`: links, CSS e scripts são resolvidos a partir da raiz do projeto. Os redirecionamentos e links dos scripts compartilhados também apontam para a nova estrutura. Os links antigos dos arquivos movidos não são mantidos.

O login em modal continua disponível no site; a página dedicada fica em `login/index.html`.

Após alterações, execute `python scripts/gerar-arquivo-unico.py` para atualizar `extras/abrir-tudo.html`. Edite os fontes separados, pois a versão única será sobrescrita pelo gerador.

## Contas de demonstração

- Administrador: `admin@conecta.org` / `Recreio@2026`.
- Alunos: `2026001` / `ana123`, `2026002` / `bruno123`, `2026003` / `clara123`.

O projeto mantém o funcionamento original: dados no localStorage e autenticação no navegador, para demonstração. Para compartilhar a sessão entre páginas, prefira o servidor local; o comportamento de localStorage em file:// depende do navegador. A versão de arquivo único mantém seu próprio contexto.
