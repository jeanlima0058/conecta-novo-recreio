"""Atualiza extras/abrir-tudo.html a partir dos arquivos organizados."""
from pathlib import Path
import json,re
ROOT=Path(__file__).resolve().parents[1]
P={}
for path in [ROOT/'index.html',*sorted(ROOT.glob('*/index.html'))]:
    text=path.read_text(encoding='utf-8').replace('<base href="../">','')
    text=re.sub(r'<link rel="stylesheet" href="([^" ]+)">',lambda m:'<style>'+ (ROOT/m[1]).read_text(encoding='utf-8')+'</style>',text)
    text=re.sub(r'<script src="(?!https?:)([^" ]+)"></script>',lambda m:'<script>'+ (ROOT/m[1]).read_text(encoding='utf-8')+'</script>',text)
    P[path.relative_to(ROOT).as_posix()]=text
payload=json.dumps(P,ensure_ascii=False).replace('</','<\\/')
nav="""
function __nav(u){const[n,h]=u.split('#'),f=document.getElementById('f');
f.onload=()=>{const d=f.contentDocument;d.addEventListener('click',e=>{const a=e.target.closest('a[href]');if(!a)return;const u=a.getAttribute('href');if(u.startsWith('#')){e.preventDefault();d.getElementById(u.slice(1))?.scrollIntoView({behavior:'smooth'})}else if(P[u.split('#')[0]]){e.preventDefault();__nav(u)}});if(h)d.getElementById(h)?.scrollIntoView()};f.srcdoc=P[n]||P['index.html']}
__nav('index.html');
"""
(ROOT/'extras/abrir-tudo.html').write_text('<!DOCTYPE html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Conecta Novo Recreio</title><style>html,body{margin:0;height:100%}iframe{border:0;width:100%;height:100%;display:block}</style></head><body><iframe id="f" title="Conecta Novo Recreio"></iframe><script>const P='+payload+';'+nav+'</script></body></html>',encoding='utf-8')
print('Arquivo único atualizado.')
