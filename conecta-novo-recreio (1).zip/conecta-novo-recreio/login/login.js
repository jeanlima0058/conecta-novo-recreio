// Código da página login/index.html
const cur=ses();if(cur)go(cur.role==='admin'?'admin/index.html':'aluno/index.html');
$('#fLogin').onsubmit=e=>{e.preventDefault();const r=login($('#u').value,$('#s').value);
 if(r)go(r.role==='admin'?'admin/index.html':'aluno/index.html');
 else{$('#lmsg').style.color='var(--bad)';$('#lmsg').textContent='Matrícula, e-mail ou senha incorretos.'}};
$('#forgot').onclick=()=>{$('#lmsg').style.color='var(--brand)';$('#lmsg').textContent='Peça uma nova senha na secretaria da instituição.'};
