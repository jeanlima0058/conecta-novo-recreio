// Código da página index.html
chrome('home');
const sl=$$('.slide'),dots=$('#dots');let i=0,tm;
sl.forEach((_,n)=>{const b=document.createElement('button');b.className='w-3 h-3 rounded-full';b.setAttribute('aria-label','Slide '+(n+1));b.onclick=()=>sw(n);dots.appendChild(b)});
function sw(n){i=(n+sl.length)%sl.length;sl.forEach((s,k)=>s.classList.toggle('on',k===i));[...dots.children].forEach((d,k)=>d.style.background=k===i?'#fff':'rgba(255,255,255,.5)');clearInterval(tm);if(!matchMedia('(prefers-reduced-motion:reduce)').matches)tm=setInterval(()=>sw(i+1),5000)}
$('#prev').onclick=()=>sw(i-1);$('#next').onclick=()=>sw(i+1);sw(0);
