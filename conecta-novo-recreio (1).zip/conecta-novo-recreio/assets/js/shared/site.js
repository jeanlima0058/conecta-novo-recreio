// Cabeçalho, rodapé, cards de curso, modal “Saiba Mais” e formulário “Cadastre-se” (páginas públicas)
const NAV=[['home','index.html','Home'],['cursos','cursos/index.html','Cursos'],['sobre','sobre/index.html','Sobre'],['doacao','doacao/index.html','Doação']];
const FB=[['Mariana, mãe de aluno','Meu filho voltou a gostar de estudar. Obrigada por tudo!'],['Lucas, 15 anos','Aprendi informática e hoje ajudo em casa com o computador.'],['Dona Rita, vizinha','Ver as crianças felizes aqui faz toda a diferença no bairro.']];
function chrome(active){
 const s=ses(),pn=s&&(s.role==='admin'?'admin/index.html':'aluno/index.html');
 $('#hdr').outerHTML=`<header class="sticky top-0 z-30 h-16" style="background:var(--card);border-bottom:1px solid var(--line)"><div class="max-w-6xl mx-auto px-4 h-full flex items-center justify-between gap-2">
 <a href="index.html" class="flex items-center gap-2 text-lg font-bold" style="font-family:Fraunces,serif;color:var(--brand)"><span aria-hidden="true" class="text-2xl">🌱</span><span class="hidden sm:inline">Semente do Amanhã</span></a>
 <nav id="nav" class="nav hidden md:flex gap-1 absolute md:static top-16 left-0 right-0 flex-col md:flex-row p-3 md:p-0" style="background:var(--card)">${NAV.map(n=>`<a href="${n[1]}"${n[0]===active?' class="on"':''}>${n[2]}</a>`).join('')}</nav>
 <div class="flex items-center gap-2"><button class="btn btn-alt btn-sm" data-enr="">Cadastre-se</button>${s?`<a href="${pn}" class="btn btn-sm">Meu painel</a>`:`<button class="btn btn-sm" data-login>Fazer Login</button>`}<button id="burger" class="md:hidden btn btn-alt btn-sm" aria-label="Abrir menu">☰</button></div></div></header>`;
 const f=$('#ftr');if(f)f.outerHTML=`<footer class="mt-8" style="background:var(--card);border-top:1px solid var(--line)"><div class="max-w-6xl mx-auto px-4 py-8 grid sm:grid-cols-3 gap-6 text-sm"><div><h3 class="font-bold mb-2">Contatos</h3><p class="mute">(11) 00000-0000<br>contato@sementedoamanha.org<br>Rua Exemplo, 123 – Guarulhos, SP</p></div><div><h3 class="font-bold mb-2">Redes sociais</h3><p class="mute">TikTok<br>Instagram<br>YouTube</p></div><div><h3 class="font-bold mb-2">Parceiros</h3><p class="mute">Parceiro 1<br>Parceiro 2</p></div></div></footer>`}
const card=c=>`<article class="card cc overflow-hidden flex flex-col">${art(c,'aspect-video')}<div class="p-5 flex flex-col flex-1"><h3 class="text-xl font-bold">${esc(c.nome)}</h3><p class="mute text-sm mb-1">${esc(c.carga)}</p><p class="mute mb-4">${esc(c.desc)}</p><div class="mt-auto grid gap-2"><button class="btn btn-alt" data-more="${c.id}">Saiba Mais</button><button class="btn" data-enr="${c.id}">Inscreva-se</button></div></div></article>`;
const feedbacks=()=>FB.map(f=>`<figure class="card p-5"><span class="stars" aria-label="5 estrelas">★★★★★</span><blockquote class="my-2">${f[1]}</blockquote><figcaption class="mute text-sm font-bold">${f[0]}</figcaption></figure>`).join('');
function openCourse(id){const c=DB.cursos.find(x=>x.id===id);if(!c)return;
 modal(`${art(c,'h-56')}<div class="p-6"><div class="flex justify-between gap-3 items-start"><h2 class="text-2xl font-bold">${esc(c.nome)}</h2><button class="btn btn-alt btn-sm" data-x aria-label="Fechar">✕</button></div>
 <div class="flex flex-wrap gap-2 my-3"><span class="tag">⏱ ${esc(c.carga)}</span><span class="tag">👧 ${esc(c.pub)}</span><span class="tag">🗓 ${esc(c.hor)}</span><span class="tag">🪑 ${esc(c.vagas)} vagas</span></div>
 <p class="mb-3">${esc(c.det||c.desc)}</p><p class="mute mb-5">Professor(a): <b>${esc(c.prof)}</b>. Gratuito, com material fornecido pela instituição.</p><button class="btn w-full" data-enr="${c.id}">Inscreva-se</button></div>`)}
function openLogin(){$$('.mdl').forEach(x=>x.remove());
 const m=modal(`<form class="p-6 space-y-4" novalidate><div class="flex justify-between items-start"><div><h2 class="text-2xl font-bold">Fazer login</h2><p class="mute text-sm mt-1">Entre com sua matrícula ou e-mail.</p></div><button type="button" class="btn btn-alt btn-sm" data-x aria-label="Fechar">✕</button></div>
 <div><label for="lu">Matrícula ou e-mail</label><input id="lu" class="inp" autocomplete="username"></div>
 <div><label for="ls">Senha</label><input id="ls" type="password" class="inp" autocomplete="current-password"></div>
 <button class="btn w-full">Entrar</button><p id="lm" class="font-bold text-center" role="status"></p>
 <div class="flex justify-between text-sm"><button type="button" id="lf" class="underline" style="color:var(--brand)">Esqueceu a senha?</button><button type="button" id="lc" class="underline" style="color:var(--brand)">Criar conta</button></div></form>`);
 const f=$('form',m.el),o=$('#lm',f);
 f.onsubmit=e=>{e.preventDefault();const r=login($('#lu',f).value,$('#ls',f).value);
  if(r){m.close();go(r.role==='admin'?'admin/index.html':'aluno/index.html')}else{o.style.color='var(--bad)';o.textContent='Matrícula, e-mail ou senha incorretos.'}};
 $('#lf',f).onclick=()=>{o.style.color='var(--brand)';o.textContent='Peça uma nova senha na secretaria da instituição.'};
 $('#lc',f).onclick=()=>openEnroll('')}
function openEnroll(id){$$('.mdl').forEach(x=>x.remove());
 const m=modal(`<form class="p-6 space-y-4" novalidate><div class="flex justify-between items-start"><h2 class="text-2xl font-bold">Criar conta</h2><button type="button" class="btn btn-alt btn-sm" data-x aria-label="Fechar">✕</button></div>
 <p class="mute text-sm">Crie sua conta de aluno e escolha o curso. Depois é só entrar com seu e-mail e senha.</p>
 <div><label for="en">Nome completo</label><input id="en" class="inp" autocomplete="name"></div><div><label for="ee">E-mail</label><input id="ee" type="email" class="inp" autocomplete="email"></div>
 <div><label for="et">Contato</label><input id="et" class="inp" inputmode="tel" placeholder="(11) 00000-0000" maxlength="15"></div>
 <div><label for="ec">Curso</label><select id="ec" class="inp"><option value="">Escolha um curso</option>${DB.cursos.map(c=>`<option value="${c.id}"${c.id==id?' selected':''}>${esc(c.nome)}</option>`).join('')}</select></div>
 <div class="grid sm:grid-cols-2 gap-3"><div><label for="es">Senha</label><input id="es" type="password" class="inp" autocomplete="new-password" placeholder="Mínimo 6 caracteres"></div><div><label for="es2">Repetir senha</label><input id="es2" type="password" class="inp" autocomplete="new-password"></div></div>
 <button class="btn w-full">Criar conta</button><p id="em" class="font-bold text-center" role="status"></p></form>`);
 const f=$('form',m.el);$('#et',f).oninput=e=>{let v=e.target.value.replace(/\D/g,'').slice(0,11);v=v.replace(/^(\d{0,2})/,'($1').replace(/^\((\d{2})(\d)/,'($1) $2').replace(/(\d{5})(\d{1,4})$/,'$1-$2');e.target.value=v.replace(/^\($/,'')};
 f.onsubmit=e=>{e.preventDefault();const n=$('#en',f).value.trim(),em=$('#ee',f).value.trim(),t=$('#et',f).value,c=DB.cursos.find(x=>x.id==$('#ec',f).value),s=$('#es',f).value,o=$('#em',f);
  const err=!n||!/\S+@\S+\.\S+/.test(em)||t.length<14||!c?'Preencha nome, e-mail, contato e curso.':s.length<6?'A senha precisa ter pelo menos 6 caracteres.':s!==$('#es2',f).value?'As senhas não são iguais.':DB.alunos.some(x=>(x.email||'').toLowerCase()===em.toLowerCase())?'Este e-mail já tem conta. Use Fazer login.':'';
  if(err){o.style.color='var(--bad)';o.textContent=err;return}
  const tu=DB.turmas.find(x=>x.curso===c.id),aid=nid(DB.alunos);
  DB.alunos.push({id:aid,nome:n,email:em,tel:t,mat:'2026'+String(aid).padStart(3,'0'),senha:s,curso:c.id,turma:tu?tu.id:0,prog:0,faltas:[],notas:[]});
  DB.inscr.push({id:nid(DB.inscr),nome:n,email:em,tel:t,curso:c.id,d:today(),aluno:aid});save();
  f.innerHTML=`<div class="text-center py-6"><div class="text-5xl mb-3">✅</div><h2 class="text-2xl font-bold mb-2">Conta criada!</h2><p class="mute mb-1">Entre com seu e-mail ou com a matrícula <b>${'2026'+String(aid).padStart(3,'0')}</b> e a senha que você escolheu.</p><p class="mute mb-5">Você está matriculado em <b>${esc(c.nome)}</b>.</p><button class="btn" id="goin" type="button">Entrar no meu painel</button></div>`;
  $('#goin',f).onclick=()=>{login(em,s);go('aluno/index.html')}}}
document.addEventListener('click',e=>{const m=e.target.closest('[data-more]'),n=e.target.closest('[data-enr]'),l=e.target.closest('[data-login]');
 if(l)openLogin();else if(m)openCourse(+m.dataset.more);else if(n)openEnroll(n.dataset.enr);else if(e.target.closest('#burger'))$('#nav').classList.toggle('hidden')});
