// Código da página cursos/index.html
chrome('cursos');$('#grid').innerHTML=DB.cursos.map(card).join('');$('#fb').innerHTML=feedbacks();
