// Painel do aluno
const s=guard('aluno'),a=s&&DB.alunos.find(x=>x.id===s.id);
if(a){
 const t=DB.turmas.find(x=>x.id===a.turma),c=DB.cursos.find(x=>x.id===(t?t.curso:a.curso)),h=today();
 const media=a.notas.length?(a.notas.reduce((m,n)=>m+n.n,0)/a.notas.length):null;
 const ev=DB.eventos.filter(e=>e.ativo!==false&&(!e.turma||e.turma===a.turma)).sort((x,y)=>x.d<y.d?-1:1);
 const av=DB.avisos.filter(x=>x.ativo!==false&&(!x.turma||x.turma===a.turma)).sort((x,y)=>x.d<y.d?1:-1);
 const aviso=x=>`<li class="p-3 rounded-lg" style="background:var(--bg)"><b>${esc(x.t)}</b> <small class="mute">${fd(x.d)}</small><p class="mute">${esc(x.x)}</p></li>`;
 $('#who').textContent='Olá, '+a.nome.split(' ')[0];
 $('#app').innerHTML=`
 <section class="card p-6 flex flex-col sm:flex-row items-center gap-6"><div class="ring" style="--p:${a.prog}" role="img" aria-label="Progresso: ${a.prog}%"><b>${a.prog}%</b></div>
  <div class="text-center sm:text-left"><p class="mute font-bold">Você está matriculado em</p><h1 class="text-3xl md:text-4xl font-bold mb-2">${c?esc(c.nome):'Nenhum curso ainda'}</h1>
  ${t?`<div class="flex flex-wrap gap-2 justify-center sm:justify-start"><span class="tag">🏫 ${esc(t.nome)}</span><span class="tag">🗓 ${esc(t.hor)}</span><span class="tag">👩‍🏫 ${esc(t.prof)}</span><span class="tag">Matrícula ${a.mat}</span></div>`:'<p class="mute">A secretaria ainda vai colocar você em uma turma.</p>'}</div></section>
 <div class="grid md:grid-cols-2 gap-6">
  <section class="card p-6"><div class="flex justify-between items-baseline mb-3"><h2 class="text-xl font-bold">Notas</h2>${media!==null?`<span class="tag">Média ${media.toFixed(1).replace('.',',')}</span>`:''}</div>
   ${a.notas.length?`<table class="tbl"><tbody>${a.notas.map(n=>`<tr><td>${esc(n.a)}</td><td class="text-right"><b style="color:${n.n>=7?'var(--leaf)':'var(--bad)'}">${n.n.toFixed(1).replace('.',',')}</b></td></tr>`).join('')}</tbody></table>`:'<p class="mute">Nenhuma nota lançada ainda.</p>'}</section>
  <section class="card p-6"><div class="flex justify-between items-baseline mb-3"><h2 class="text-xl font-bold">Faltas</h2><span class="tag">${a.faltas.length} no total</span></div>
   ${a.faltas.length?`<table class="tbl"><tbody>${a.faltas.map(f=>`<tr><td>${fd(f.d)}</td><td class="mute">${esc(f.m)}</td></tr>`).join('')}</tbody></table>`:'<p class="mute">Nenhuma falta. Continue assim!</p>'}</section>
  <section class="card p-6"><h2 class="text-xl font-bold mb-3">Datas importantes</h2>
   ${ev.length?`<ul class="space-y-2">${ev.map(e=>{const[y,m,d]=e.d.split('-');return `<li class="flex items-center gap-3" style="${e.d<h?'opacity:.5':''}"><div class="text-center rounded-lg px-3 py-1 text-white" style="background:var(--brand);min-width:3.5rem"><b class="block text-xl leading-tight">${d}</b><small>${['jan','fev','mar','abr','mai','jun','jul','ago','set','out','nov','dez'][+m-1]}</small></div><div><b>${esc(e.t)}</b><br><small class="mute">${e.turma?'Sua turma':'Toda a instituição'}${e.d<h?' · já passou':''}</small></div></li>`}).join('')}</ul>`:'<p class="mute">Sem datas marcadas.</p>'}</section>
  <section class="card p-6"><h2 class="text-xl font-bold mb-3">Mural de avisos</h2>
   ${av.length?`<ul class="space-y-3">${av.map(x=>`<li>${x.turma?'<span class="tag mb-1" style="border-color:var(--brand)">Sua turma</span>':'<span class="tag mb-1">Instituição</span>'}<ul>${aviso(x)}</ul></li>`).join('')}</ul>`:'<p class="mute">Nenhum aviso por enquanto.</p>'}</section>
 </div>`;
 $('#out').onclick=logout;
}
